#include "stm32f10x.h"                  // Device header
#include "Delay.h"

void MyI2C_SetSCL(uint8_t bit)
{
	GPIO_WriteBit(GPIOB, GPIO_Pin_8, (BitAction)bit);
	Delay_us(10);
}

void MyI2C_SetSDA(uint8_t bit)
{
	GPIO_WriteBit(GPIOB, GPIO_Pin_9, (BitAction)bit);
	Delay_us(10);
}

uint8_t MyI2C_ReadSDA(void)
{
	uint8_t bit;
	bit = GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_9);
	Delay_us(10);
	return bit;
}

void MyI2C_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_OD;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 |GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	GPIO_SetBits(GPIOB, GPIO_Pin_8 | GPIO_Pin_9);
}

void MyI2C_Start(void)
{
	MyI2C_SetSDA(1);
	MyI2C_SetSCL(1);
	MyI2C_SetSDA(0);
	MyI2C_SetSCL(0);
}

void MyI2C_Stop(void)
{
	MyI2C_SetSDA(0);
	MyI2C_SetSCL(1);
	MyI2C_SetSDA(1);
}

void MyI2C_SendByte(uint8_t Byte)
{
	uint8_t i;
	for(i=0; i<8; i++)
	{
		MyI2C_SetSDA(Byte&(0x80 >> i));
		MyI2C_SetSCL(1);
		MyI2C_SetSCL(0);
	}
}

void MyI2C_SendACK(uint8_t ACKbit)
{
	MyI2C_SetSDA(ACKbit);
	MyI2C_SetSCL(1);
	MyI2C_SetSCL(0);
}

uint8_t MyI2C_ReceiveByte(void)
{
	uint8_t Byte = 0x00, i;
	MyI2C_SetSDA(1);
	for(i=0; i<8; i++)
	{
		MyI2C_SetSCL(1);
		if(MyI2C_ReadSDA()){Byte|=(0x80 >> i);}
		MyI2C_SetSCL(0);
	}
	return Byte;
}

uint8_t MyI2C_ReceiveACK(void)
{
	uint8_t ACKBit = 0;
	MyI2C_SetSDA(1);
	MyI2C_SetSCL(1);
	ACKBit=MyI2C_ReadSDA();
	MyI2C_SetSCL(0);
	return ACKBit;
}
