#include "stm32f10x.h"
#include <string.h>
#include "OLED_Sheet.h"
#include "MyI2C.h"
#include "Delay.h"

/*OLED写指令函数*/
void OLED_WriteCommand(uint8_t Command)
{
    MyI2C_Start();
    MyI2C_SendByte(0x78);       //设备地址
    MyI2C_ReceiveACK();
    MyI2C_SendByte(0x00);       //不连续，写指令模式
    MyI2C_ReceiveACK();
    MyI2C_SendByte(Command);    //写入指令
    MyI2C_ReceiveACK();
    MyI2C_Stop();
}

/*OLED写数据函数*/
void OLED_WriteData(uint8_t Data)
{
    MyI2C_Start();
    MyI2C_SendByte(0x78);       //设备地址
    MyI2C_ReceiveACK();
    MyI2C_SendByte(0x40);       //不连续，写数据模式
    MyI2C_ReceiveACK();
    MyI2C_SendByte(Data);       //写入数据
    MyI2C_ReceiveACK();
    MyI2C_Stop();
}

/*光标设置函数*/
void OLED_SetLoc(uint8_t X, uint8_t Page)
{
    OLED_WriteCommand(0x00 | (X & 0x0F));
    OLED_WriteCommand(0x10 | ((X & 0xF0) >> 4));    //X:0~127

    OLED_WriteCommand(0xB0 | Page);
}

/*初始化函数*/
void OLED_Init(void)
{
    MyI2C_Init();

    Delay_ms(100);

    OLED_WriteCommand(0xAE);

    OLED_WriteCommand(0xD5);
    OLED_WriteCommand(0x80);

    OLED_WriteCommand(0xA8);
    OLED_WriteCommand(0x3F);

    OLED_WriteCommand(0xD3);
    OLED_WriteCommand(0x00);

    OLED_WriteCommand(0x40);

    OLED_WriteCommand(0xA1);

    OLED_WriteCommand(0xC8);

    OLED_WriteCommand(0xDA);
    OLED_WriteCommand(0x12);

    OLED_WriteCommand(0x81);
    OLED_WriteCommand(0xCF);

    OLED_WriteCommand(0xD9);
    OLED_WriteCommand(0xF1);

    OLED_WriteCommand(0xD8);
    OLED_WriteCommand(0x30);

    OLED_WriteCommand(0xA4);

    OLED_WriteCommand(0xA6);

    OLED_WriteCommand(0x8D);
    OLED_WriteCommand(0x14);

    OLED_WriteCommand(0xAF);

    Delay_ms(100);
}

/*清屏函数*/
void OLED_Clear(void)
{
    uint8_t i = 0, j = 0;

    for(i=0; i<8; i++)
    {
        OLED_SetLoc(0, i);
        for(j=0; j<128; j++)
        {
            OLED_WriteData(0x00);
        }
    }
}

/*字符显示函数*/
void OLED_ShowChar(uint8_t X, uint8_t Page, char Node, uint8_t FrontSize)
{
    uint8_t i = 0;

    if(FrontSize == 8)
    {
        OLED_SetLoc(X, Page);

        for(i=0; i<8; i++)
        {
            //使用字符本身作为索引，想SSD1306写入字符数据
            OLED_WriteData(OLED_F8x16[Node - ' '][i]);
        }

        OLED_SetLoc(X, Page + 1);

        for(i=8; i<16; i++)
        {
            OLED_WriteData(OLED_F8x16[Node - ' '][i]);
        }
    }

    if(FrontSize == 6)
    {
        OLED_SetLoc(X, Page);

        for(i=0; i<6; i++)
        {
            OLED_WriteData(OLED_F6x8[Node - ' '][i]);
        }
    }
}

/*字符串显示函数*/
void OLED_ShowString(uint8_t X, uint8_t Page, char *String, uint8_t FrontSize)
{
    uint8_t i = 0;

    if(FrontSize == 8)
    {
        for(i=0; String[i]!='\0'; i++)
        {
            //底层调用显示字符函数，向右偏移字符宽度即可
            OLED_ShowChar(X + (i * 8), Page, String[i], 8);
        }
    }

    if(FrontSize == 6)
    {
        for(i=0; String[i]!='\0'; i++)
        {
            OLED_ShowChar(X + (i * 6), Page, String[i], 6);
        }
    }
}

/*图像显示函数*/
void OLED_ShowImage(uint8_t X, uint8_t Page, uint8_t Width, uint8_t Height, const uint8_t *Image)
{
    uint8_t i = 0, j = 0;

    for(i=0; i<Height; i++)
    {
        OLED_SetLoc(X, Page + i);

        for(j=0; j<Width; j++)
        {
            OLED_WriteData(Image[j + Width * i]);
        }
    }
}
