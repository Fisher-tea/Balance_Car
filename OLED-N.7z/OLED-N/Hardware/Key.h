#ifndef __KEY_H__
#define __KEY_H__

void KEY_Init(void);
uint8_t GetKeyNum(void);

#endif
