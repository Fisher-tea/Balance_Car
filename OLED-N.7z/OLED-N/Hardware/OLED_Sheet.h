#ifndef __OLED_SHEET_H__
#define __OLED_SHEET_H__

//基础常用用字符8x16、6x8大小
extern const uint8_t OLED_F8x16[][16];
extern const uint8_t OLED_F6x8[][6];

//自定义图片
extern const uint8_t Img_fu[];

#endif
