#ifndef __OLED_H__
#define __OLED_H__

#define     Front8x16       8
#define     Front6x8        6

//OLED初始化、清屏函数
void OLED_Init(void);
void OLED_Clear(void);

//OLED写指令、数据函数，外部一般不调用
void OLED_WriteCommand(uint8_t Command);
void OLED_WriteData(uint8_t Data);
void OLED_SetLoc(uint8_t X, uint8_t Page);

//OLED基础显示函数
void OLED_ShowChar(uint8_t X, uint8_t Page, char Node, uint8_t FrontSize);
void OLED_ShowString(uint8_t X, uint8_t Page, char *String, uint8_t FrontSize);
void OLED_ShowImage(uint8_t X, uint8_t Page, uint8_t Width, uint8_t Height, const uint8_t *Image);

#endif
