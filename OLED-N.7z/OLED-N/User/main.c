#include "stm32f10x.h"                  // Device header
#include <string.h>
#include "Delay.h"
#include "OLED.h"
#include "OLED_Sheet.h"

int main(void)
{
	char str[100];
	uint8_t i = 0;
	
    OLED_Init();
    OLED_Clear();

    // OLED_ShowChar(20, 6, 'G', 6);
    // OLED_ShowString(20, 0, "Hello World!", Front8x16);
	
	while(1)
	{
        //数字的显示使用sprintf格式化转换为字符显示
		sprintf(str, "The num is %d", i++);
        
		OLED_ShowString(0, 0, str, Front6x8);
		Delay_ms(500);
	}
}
